package com.jira.jira.entity;

public enum Priority {
    LOW, MEDIUM, HIGH
}
