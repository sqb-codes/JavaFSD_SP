package com.jira.jira.entity;

public enum Role {
    ADMIN, MANAGER, DEVELOPER, TESTER
}
