package com.jira.jira.entity;

public enum Status {
    OPEN, READY, IN_PROGRESS, DONE
}

